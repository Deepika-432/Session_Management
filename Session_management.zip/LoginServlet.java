package com.kce.servlet;
import javax.servlet.http.Cookie;
import javax.servlet.RequestDispatcher;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public LoginServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//form data 
				String user=request.getParameter("mail");
				String pswd=request.getParameter("pswd");
				
				if(user.equalsIgnoreCase("admin@kce.ac.in")) {
					RequestDispatcher rd=request.getRequestDispatcher("AdminServlet");
					rd.forward(request,response);
				}
				else {
					
					//HttpSession session=request.getSession();
		     	   	//Session.setAtribute("User",userdata[0]);
					String userdata[]=user.split("@");
					Cookie c=new Cookie("user",userdata[0]);
					response.addCookie(c);
					RequestDispatcher rd=request.getRequestDispatcher("UserServlet");
					rd.forward(request,response);
					
					
				}
	}

}
