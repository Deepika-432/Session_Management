package com.kce.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import javax.servlet.http.Cookie;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//HttpSession session=request.getSession();
		//String user=(String)session.getAttribute("user");
		Cookie[] c=request.getCookies();
		String user=c[0].getValue().toString();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.print("<h5>Welcom to User page</h5>");
		out.print("<h5>"+user+"<p>");
	}

}
